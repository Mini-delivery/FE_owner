package com.example.minidelivery.ui.managedelivery

class ManageDeliveryViewModel {

}